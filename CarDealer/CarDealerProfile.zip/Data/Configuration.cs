﻿namespace CarDealer.Data
{
    public static class Configuration
    {
        public const string ConnectionString = @"Server = KRASIMIR; Database = CarDealer;TrustServerCertificate=True; Trusted_Connection = True;";
    }
}
